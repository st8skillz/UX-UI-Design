(function(window, undefined) {
  var dictionary = {
    "f6fa9309-5f63-4677-87f4-84739e748a33": "Recording",
    "cae182a6-15f6-4b4a-9e51-6ace9b9b350b": "Blank Temp",
    "93f1898c-f422-4019-9aae-c365cd960c0b": "menu",
    "43eddf88-b284-46cb-8692-35e100016189": "LOG IN UNPW",
    "ca6e9ba8-a416-42d2-864e-0deb31741f39": "Saved Recordings",
    "767e28b8-b6ac-47a0-8cd2-f637ba3f9701": "forgot password",
    "281ada69-a12b-4cc5-b5aa-3b4f53d15220": "Quick Acess",
    "ce1f4dd1-1acc-46f1-b001-657ad5e9d26d": "REVIEWS",
    "9391fb25-d7fd-4bf4-9ed9-e3029b4b8f01": "Dashboard Home",
    "4208328e-8115-4e27-b2c5-8e1e46a57826": "Contacts",
    "b6f8e282-08d0-4f1d-a787-271187cfa8c8": "Face ID ALT",
    "a6905028-8d71-4581-9ffa-09cfacbbb537": "Record home",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);