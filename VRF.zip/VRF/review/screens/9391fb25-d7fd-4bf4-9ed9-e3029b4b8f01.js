var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1586835786953.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1586835786953-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1586835786953-ie8.css" /><![endif]-->\
      <div id="t-Empty_screen_color_top" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="640px" dataX="0" dataY="0" >\
        <div id="t-Screen-bg" class="pie percentage richtext firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="100%" dataX="0" dataY="0" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-t-Screen-bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="t-Softkeys-bg" class="pie percentage rectangle firer commentable pin vpin-end hpin-center non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="48px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-t-Softkeys-bg_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="t-Square" class="pie image lockV firer ie-background commentable pin vpin-end hpin-end non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="74" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/737f2e61-6a0d-4c0b-9e29-a910b89e583b.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>recent</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="t-Square-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-273.000000, -16.000000)" fill="#FFFFFF">\
                        <g id="t-Square-Group-3" transform="translate(231.000000, 0.000000)">\
                            <rect id="t-Square-recent" x="42" y="16" width="16" height="16" rx="1"></rect>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="t-Circle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-center non-processed-pin non-processed"   datasizewidth="18px" datasizeheight="18px" dataX="0" dataY="15" aspectRatio="1.0"   alt="image" systemName="./images/025304dc-7632-4290-965a-2ccfd1a09e68.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>home</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="t-Circle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-170.000000, -14.000000)">\
                        <g id="t-Circle-Group-4" transform="translate(130.000000, 0.000000)">\
                            <g id="t-Circle-home" transform="translate(40.000000, 14.000000)">\
                                <circle fill="#FFFFFF" fill-rule="evenodd" cx="10" cy="10" r="6"></circle>\
                                <circle stroke="#FFFFFF" stroke-width="2" cx="10" cy="10" r="9"></circle>\
                            </g>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="t-Triangle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="76" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/958c6a48-d7fb-48cf-87ea-71cf9d4e5ead.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="15px" height="17px" viewBox="0 0 15 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>back</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="t-Triangle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-72.000000, -15.000000)" fill="#FFFFFF">\
                        <g id="t-Triangle-Group-2" transform="translate(29.000000, 0.000000)">\
                            <path d="M56.2719481,15.2473593 C57.2263246,14.695639 57.9999997,15.1409225 57.9999997,16.2463373 L58,30.7555624 C58,31.859003 57.2280325,32.3072478 56.2719485,31.7545403 L43.7227789,24.4999276 C42.7684024,23.9482072 42.7666949,23.0546789 43.7227789,22.5019715 L56.2719481,15.2473593 Z" id="t-Triangle-back"></path>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="t-Bg" class="pie percentage label singleline firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-Bg_0">VRF</span></div></div></div></div>\
        <div id="t-more-vertical" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="36"   alt="image" systemName="./images/9fe8df66-3ac1-4b07-a01d-a848692a9985.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
        </div>\
        <div id="t-menu" class="pie image firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="13" dataY="36"   alt="image" systemName="./images/066895b4-233e-4792-b154-5550b406ec47.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
        </div>\
        <div id="t-Status-bar" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="20px" dataX="0" dataY="0" >\
          <div id="t-Bg_status" class="pie percentage rectangle firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="20px" dataX="0" dataY="0" >\
           <div class="backgroundLayer"></div>\
           <div class="paddingLayer">\
             <div class="clipping">\
               <div class="content">\
                 <div class="valign">\
                   <span id="rtr-t-Bg_status_0"><br /></span>\
                 </div>\
               </div>\
             </div>\
           </div>\
          </div>\
          <div id="t-hour" class="pie label singleline firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="46px" datasizeheight="20px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-hour_0">15:45</span></div></div></div></div>\
\
          <div id="t-signals" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="61px" datasizeheight="20px" dataX="8" dataY="0"   alt="image">\
              <img src="./images/4ddcfd62-95e9-425c-88ad-7243a8588cc0.png" />\
          </div>\
        </div>\
      </div>\
      <div id="t-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="20px" dataX="55" dataY="157" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-Text_1_0"></span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-9391fb25-d7fd-4bf4-9ed9-e3029b4b8f01" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Dashboard Home" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/9391fb25-d7fd-4bf4-9ed9-e3029b4b8f01-1586835786953.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/9391fb25-d7fd-4bf4-9ed9-e3029b4b8f01-1586835786953-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/9391fb25-d7fd-4bf4-9ed9-e3029b4b8f01-1586835786953-ie8.css" /><![endif]-->\
      <div id="s-Empty_screen_color_top" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="640px" dataX="0" dataY="0" >\
        <div id="s-Screen-bg" class="pie percentage richtext firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="100%" dataX="0" dataY="0" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Screen-bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Softkeys-bg" class="pie percentage rectangle firer commentable pin vpin-end hpin-center non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="48px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Softkeys-bg_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Square" class="pie image lockV firer ie-background commentable pin vpin-end hpin-end non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="74" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/737f2e61-6a0d-4c0b-9e29-a910b89e583b.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>recent</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="s-Square-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-273.000000, -16.000000)" fill="#FFFFFF">\
                        <g id="s-Square-Group-3" transform="translate(231.000000, 0.000000)">\
                            <rect id="s-Square-recent" x="42" y="16" width="16" height="16" rx="1"></rect>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Circle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-center non-processed-pin non-processed"   datasizewidth="18px" datasizeheight="18px" dataX="0" dataY="15" aspectRatio="1.0"   alt="image" systemName="./images/025304dc-7632-4290-965a-2ccfd1a09e68.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>home</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="s-Circle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-170.000000, -14.000000)">\
                        <g id="s-Circle-Group-4" transform="translate(130.000000, 0.000000)">\
                            <g id="s-Circle-home" transform="translate(40.000000, 14.000000)">\
                                <circle fill="#FFFFFF" fill-rule="evenodd" cx="10" cy="10" r="6"></circle>\
                                <circle stroke="#FFFFFF" stroke-width="2" cx="10" cy="10" r="9"></circle>\
                            </g>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Triangle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="76" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/958c6a48-d7fb-48cf-87ea-71cf9d4e5ead.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="15px" height="17px" viewBox="0 0 15 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>back</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="s-Triangle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-72.000000, -15.000000)" fill="#FFFFFF">\
                        <g id="s-Triangle-Group-2" transform="translate(29.000000, 0.000000)">\
                            <path d="M56.2719481,15.2473593 C57.2263246,14.695639 57.9999997,15.1409225 57.9999997,16.2463373 L58,30.7555624 C58,31.859003 57.2280325,32.3072478 56.2719485,31.7545403 L43.7227789,24.4999276 C42.7684024,23.9482072 42.7666949,23.0546789 43.7227789,22.5019715 L56.2719481,15.2473593 Z" id="s-Triangle-back"></path>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Bg" class="pie percentage label singleline firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Bg_0">VRF DASHBOARD HOME</span></div></div></div></div>\
        <div id="s-more-vertical" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="36"   alt="image" systemName="./images/9fe8df66-3ac1-4b07-a01d-a848692a9985.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
        </div>\
        <div id="s-menu" class="pie image firer click ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="13" dataY="36"   alt="image" systemName="./images/066895b4-233e-4792-b154-5550b406ec47.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
        </div>\
        <div id="s-Status-bar" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="20px" dataX="0" dataY="0" >\
          <div id="s-Bg_status" class="pie percentage rectangle firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="20px" dataX="0" dataY="0" >\
           <div class="backgroundLayer"></div>\
           <div class="paddingLayer">\
             <div class="clipping">\
               <div class="content">\
                 <div class="valign">\
                   <span id="rtr-s-Bg_status_0"><br /></span>\
                 </div>\
               </div>\
             </div>\
           </div>\
          </div>\
          <div id="s-hour" class="pie label singleline firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="46px" datasizeheight="20px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-hour_0">15:45</span></div></div></div></div>\
\
          <div id="s-signals" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="61px" datasizeheight="20px" dataX="8" dataY="0"   alt="image">\
              <img src="./images/4ddcfd62-95e9-425c-88ad-7243a8588cc0.png" />\
          </div>\
        </div>\
\
        <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="89px" datasizeheight="79px" dataX="227" dataY="176"   alt="image">\
            <img src="./images/93fd287a-6a36-42d5-bc17-a059005fe472.png" />\
        </div>\
\
        <div id="s-Image_2" class="pie image firer click ie-background commentable non-processed"   datasizewidth="86px" datasizeheight="79px" dataX="71" dataY="176"   alt="image">\
            <img src="./images/2140f425-bebd-4253-9e03-6ba717d66648.png" />\
        </div>\
\
        <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="86px" datasizeheight="78px" dataX="71" dataY="315"   alt="image">\
            <img src="./images/dcdd922d-a89f-4344-9cef-43af411331df.jpg" />\
        </div>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="20px" dataX="55" dataY="157" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0"></span></div></div></div></div>\
      <div id="s-Image_25" class="pie image firer click ie-background commentable non-processed"   datasizewidth="88px" datasizeheight="75px" dataX="232" dataY="315"   alt="image" systemName="./images/e84aed9f-e9dc-4372-b855-c3280043a696.svg" overlay="#A9A9A9">\
          <?xml version="1.0" encoding="UTF-8"?>\
          <svg preserveAspectRatio=\'none\' width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
              <!-- Generator: Sketch 48.2 (47327) - http://www.bohemiancoding.com/sketch -->\
              <title>Emoji</title>\
              <desc>Created with Sketch.</desc>\
              <defs></defs>\
              <g id="s-Image_25-iPhone-X" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" transform="translate(-85.000000, -286.000000)">\
                  <path d="M97,286 C103.627417,286 109,291.372583 109,298 C109,304.627417 103.627417,310 97,310 C90.372583,310 85,304.627417 85,298 C85,291.372583 90.372583,286 97,286 Z M97,287.398 C102.855167,287.398663 107.601242,292.145633 107.6008,298.0008 C107.600358,303.855967 102.853567,308.602221 96.9984,308.602 C91.1432333,308.601779 86.3968,303.855167 86.3968,298 C86.3968796,295.187991 87.5140631,292.491195 89.502566,290.502917 C91.491069,288.51464 94.1879913,287.397761 97,287.398 Z M93.2038,292.795 C92.8328936,292.790581 92.4757063,292.935085 92.2122077,293.196158 C91.9487092,293.457232 91.8009098,293.813069 91.8019,294.184 C91.8019,294.958248 92.429552,295.5859 93.2038,295.5859 C93.978048,295.5859 94.6057,294.958248 94.6057,294.184 C94.6066902,293.813069 94.4588908,293.457232 94.1953923,293.196158 C93.9318937,292.935085 93.5747064,292.790581 93.2038,292.795 Z M104.9971,300.067 C104.3581,303.52 101.0254,306.403 96.9985,306.403 C93.0037,306.403 89.6905,303.562 89.014,300.148 C88.8769,299.296 89.5747,299.095 90.232,299.254 C92.4308704,299.88979 94.7112173,300.199092 97,300.172 C99.2836089,300.198477 101.558775,299.890202 103.753,299.257 C104.392,299.095 105.0763,299.278 104.9971,300.067 Z M102.8278,300.547 C102.7654,300.571 102.7021,300.589 102.6382,300.61 C102.6316,300.613 102.8428,300.544 102.8365,300.547 C100.939091,301.069345 98.977763,301.322817 97.0099,301.3 C94.6615,301.3 92.5612,301.039 91.1158,300.52 C90.0679,300.208 90.2689,301.441 91.0054,301.819 C92.8895613,302.676755 94.9395199,303.108994 97.0096,303.085 C99.472,303.085 101.6662,302.512 103.1155,301.771 C103.8013,301.33 103.9369,300.148 102.8278,300.547 Z M100.804,292.795 C100.433066,292.790582 100.075849,292.935076 99.8123027,293.196141 C99.5487567,293.457206 99.4008903,293.813041 99.4018,294.184 C99.3944012,294.689792 99.6600004,295.160362 100.096838,295.415417 C100.533675,295.670473 101.074025,295.670473 101.510862,295.415417 C101.9477,295.160362 102.213299,294.689792 102.2059,294.184 C102.206809,293.813094 102.058983,293.457305 101.795503,293.196249 C101.532022,292.935193 101.174882,292.790663 100.804,292.795 Z" id="s-Image_25-Emoji" fill="#9B9B9B"></path>\
              </g>\
          </svg>\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="59px" datasizeheight="20px" dataX="242" dataY="138" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">RECORD</span></div></div></div></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="67px" datasizeheight="20px" dataX="242" dataY="277" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">REVIEWS </span></div></div></div></div>\
      <div id="s-Image_10" class="pie image firer click ie-background commentable non-processed"   datasizewidth="96px" datasizeheight="88px" dataX="228" dataY="459"   alt="image" systemName="./images/2e54625e-ebc8-42cd-b296-533e30a84536.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z"/></svg>\
      </div>\
      <div id="s-Chart" class="group firer ie-background commentable non-processed" datasizewidth="103px" datasizeheight="93px" dataX="64" dataY="456" >\
        <div id="shapewrapper-s-Triangle_1" class="shapewrapper shapewrapper-s-Triangle_1 non-processed"  rotationdeg="342" datasizewidth="2px" datasizeheight="63px" dataX="42" dataY="18" originalwidth="2px" originalheight="63px" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Triangle_1" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Triangle_1)">\
                            <path id="s-Triangle_1" class="pie triangle shape non-processed-shape firer commentable non-processed" d="M 1 0 L 2 63 L 0 63 Z">\
                            </path>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Triangle_1" class="clipPath">\
                            <path d="M 1 0 L 2 63 L 0 63 Z">\
                            </path>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="shapert-clipping">\
                <div id="shapert-s-Triangle_1" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Triangle_1_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="4px" datasizeheight="5px" dataX="49" dataY="77" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_1)">\
                            <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="2.0" cy="2.5" rx="2.0" ry="2.5">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                            <ellipse cx="2.0" cy="2.5" rx="2.0" ry="2.5">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="shapert-clipping">\
                <div id="shapert-s-Ellipse_1" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_1_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="55px" datasizeheight="18px" dataX="24" dataY="75" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">87 km/h</span></div></div></div></div>\
        <div id="s-Image_4" class="pie image firer ie-background commentable non-processed"   datasizewidth="33px" datasizeheight="86px" dataX="0" dataY="5"   alt="image" systemName="./images/8125e6f0-9276-45be-9302-e0d5e6050bbf.svg" overlay="#84B761">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="160px" height="358px" viewBox="0 0 160 358" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
                <title>Path</title>\
                <desc>Created with Sketch.</desc>\
                <g id="s-Image_4-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <path d="M38.3,354.9 L34,357.4 C-35,237.8 5.9,84.9 125.5,15.9 C135.8,9.9 146.5,4.7 157.6,0.3 L159.5,4.9 C33.8,55.3 -27.2,197.9 23,323.5 C27.4,334.3 32.5,344.8 38.3,354.9 Z" id="s-Image_4-Path" fill="#84B761"></path>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Image_5" class="pie image firer ie-background commentable non-processed"   datasizewidth="38px" datasizeheight="6px" dataX="32" dataY="0"   alt="image" systemName="./images/e3655ba0-8ffc-400f-b344-e5ea4f8976cf.svg" overlay="#FDD400">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="187px" height="23px" viewBox="0 0 187 23" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
                <title>Path2</title>\
                <desc>Created with Sketch.</desc>\
                <g id="s-Image_5-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <path d="M2.4,23 L0.5,18.4 C60.1,-5.5 126.7,-5.5 186.3,18.4 L184.4,23 C126.1,-0.4 60.9,-0.4 2.4,23 Z" id="s-Image_5-Path2" fill="#FDD400"></path>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Image_6" class="pie image firer ie-background commentable non-processed"   datasizewidth="34px" datasizeheight="86px" dataX="69" dataY="5"   alt="image" systemName="./images/b42c2f50-c32c-4bcc-a3eb-5b6111ea70f4.svg" overlay="#CC4748">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="163px" height="358px" viewBox="0 0 163 358" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
                <title>Path3</title>\
                <desc>Created with Sketch.</desc>\
                <g id="s-Image_6-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <path d="M0.6,12.4 L5.4,0.3 C133.6,51.6 195.9,197.1 144.6,325.3 C140.2,336.4 135,347.1 129,357.4 L117.7,350.9 C183.1,237.5 144.3,92.6 31,27.2 C21.2,21.6 11.1,16.6 0.6,12.4 Z" id="s-Image_6-Path3" fill="#CC4748"></path>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Image_7" class="pie image firer ie-background commentable non-processed"   datasizewidth="103px" datasizeheight="91px" dataX="0" dataY="0"   alt="image" systemName="./images/c365164b-91dd-426d-ab30-9722d0e82a43.svg" overlay="">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="501px" height="377px" viewBox="0 0 501 377" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
                <title>Group</title>\
                <desc>Created with Sketch.</desc>\
                <g id="s-Image_7-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="s-Image_7-Group">\
                        <path d="M34.9,374.9 L34,375.4 C-35,255.8 5.9,102.9 125.5,33.9 C245.1,-35.1 398,5.9 467,125.4 C511.7,202.8 511.7,298 467,375.4 L466.1,374.9 C534.9,255.8 494.1,103.5 375,34.8 C255.9,-33.9 103.6,6.8 34.9,125.9 C-9.6,203 -9.6,297.9 34.9,374.9 Z" id="s-Image_7-Path" fill-opacity="0.2" fill="#000000"></path>\
                        <path d="M34.7,375.8 L43.4,370.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M25.8,359 L30.3,356.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M18.2,341.6 L22.9,339.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M12,323.6 L16.8,322.1" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M7.2,305.2 L12.1,304.1" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M3.7,286.5 L13.6,285.1" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M1.8,267.6 L6.8,267.3" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M1.2,248.6 L6.2,248.6" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M2.1,229.6 L7.1,230" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M4.5,210.7 L9.4,211.5" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M8.2,192.1 L17.9,194.5" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M13.4,173.8 L18.2,175.3" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M20,155.9 L24.6,157.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M27.9,138.6 L32.4,140.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M37.1,122 L41.4,124.6" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M47.5,106 L55.6,111.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M59.1,91 L62.9,94.2" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M71.9,76.9 L75.5,80.4" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M85.6,63.7 L88.9,67.4" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M100.4,51.7 L103.4,55.7" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M115.9,40.8 L121.3,49.2" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M132.3,31.1 L134.7,35.5" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M149.4,22.7 L151.4,27.3" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M167.1,15.7 L168.8,20.4" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M185.2,10 L186.5,14.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M203.7,5.7 L205.6,15.5" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M222.5,2.8 L223.1,7.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M241.5,1.3 L241.7,6.3" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M260.5,1.3 L260.3,6.3" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M279.5,2.8 L278.9,7.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M298.3,5.7 L296.4,15.5" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M316.8,10 L315.5,14.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M334.9,15.7 L333.2,20.4" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M352.6,22.7 L350.6,27.3" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M369.7,31.1 L367.3,35.5" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M386.1,40.8 L380.7,49.2" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M401.6,51.7 L398.6,55.7" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M416.4,63.7 L413.1,67.4" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M430.1,76.9 L426.5,80.4" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M442.9,91 L439.1,94.2" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M454.5,106 L446.4,111.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M464.9,122 L460.6,124.6" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M474.1,138.6 L469.6,140.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M482,155.9 L477.4,157.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M488.6,173.8 L483.8,175.3" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M493.8,192.1 L484.1,194.5" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M497.5,210.7 L492.6,211.5" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M499.9,229.6 L494.9,230" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M500.8,248.6 L495.8,248.6" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M500.2,267.6 L495.2,267.3" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M498.3,286.5 L488.4,285.1" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M494.8,305.2 L489.9,304.1" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M490,323.6 L485.2,322.1" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M483.8,341.6 L479.1,339.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M476.2,359 L471.7,356.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                        <path d="M467.3,375.8 L458.6,370.8" id="s-Image_7-Path" stroke-opacity="0.2" stroke="#555555"></path>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="16px" dataX="9" dataY="75" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">0</span></div></div></div></div>\
        <div id="s-Text_6" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="14px" datasizeheight="16px" dataX="3" dataY="58" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">20</span></div></div></div></div>\
        <div id="s-Text_7" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="14px" datasizeheight="16px" dataX="4" dataY="39" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">40</span></div></div></div></div>\
        <div id="s-Text_8" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="14px" datasizeheight="16px" dataX="11" dataY="23" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_8_0">60</span></div></div></div></div>\
        <div id="s-Text_9" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="14px" datasizeheight="16px" dataX="22" dataY="11" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_9_0">80</span></div></div></div></div>\
        <div id="s-Text_10" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="16px" dataX="34" dataY="4" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_10_0">100</span></div></div></div></div>\
        <div id="s-Text_11" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="16px" dataX="48" dataY="4" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_11_0">120</span></div></div></div></div>\
        <div id="s-Text_12" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="16px" dataX="60" dataY="11" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_12_0">140</span></div></div></div></div>\
        <div id="s-Text_13" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="16px" dataX="71" dataY="23" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_13_0">160</span></div></div></div></div>\
        <div id="s-Text_14" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="16px" dataX="77" dataY="40" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_14_0">180</span></div></div></div></div>\
        <div id="s-Text_15" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="16px" dataX="78" dataY="58" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_15_0">200</span></div></div></div></div>\
        <div id="s-Text_16" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="16px" dataX="73" dataY="75" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_16_0">220</span></div></div></div></div>\
      </div>\
      <div id="s-Text_17" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="77px" datasizeheight="20px" dataX="237" dataY="429" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_17_0">FAVORITES</span></div></div></div></div>\
      <div id="s-Text_18" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="149px" datasizeheight="20px" dataX="35" dataY="138" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_18_0">FILES &amp; RECORDINGS</span></div></div></div></div>\
      <div id="s-Text_19" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="79px" datasizeheight="20px" dataX="76" dataY="429" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_19_0">STATISTICS</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;