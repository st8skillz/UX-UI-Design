var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1586835786953.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1586835786953-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1586835786953-ie8.css" /><![endif]-->\
      <div id="t-Empty_screen_color_top" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="640px" dataX="0" dataY="0" >\
        <div id="t-Screen-bg" class="pie percentage richtext firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="100%" dataX="0" dataY="0" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-t-Screen-bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="t-Softkeys-bg" class="pie percentage rectangle firer commentable pin vpin-end hpin-center non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="48px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-t-Softkeys-bg_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="t-Square" class="pie image lockV firer ie-background commentable pin vpin-end hpin-end non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="74" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/737f2e61-6a0d-4c0b-9e29-a910b89e583b.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>recent</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="t-Square-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-273.000000, -16.000000)" fill="#FFFFFF">\
                        <g id="t-Square-Group-3" transform="translate(231.000000, 0.000000)">\
                            <rect id="t-Square-recent" x="42" y="16" width="16" height="16" rx="1"></rect>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="t-Circle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-center non-processed-pin non-processed"   datasizewidth="18px" datasizeheight="18px" dataX="0" dataY="15" aspectRatio="1.0"   alt="image" systemName="./images/025304dc-7632-4290-965a-2ccfd1a09e68.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>home</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="t-Circle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-170.000000, -14.000000)">\
                        <g id="t-Circle-Group-4" transform="translate(130.000000, 0.000000)">\
                            <g id="t-Circle-home" transform="translate(40.000000, 14.000000)">\
                                <circle fill="#FFFFFF" fill-rule="evenodd" cx="10" cy="10" r="6"></circle>\
                                <circle stroke="#FFFFFF" stroke-width="2" cx="10" cy="10" r="9"></circle>\
                            </g>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="t-Triangle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="76" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/958c6a48-d7fb-48cf-87ea-71cf9d4e5ead.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="15px" height="17px" viewBox="0 0 15 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>back</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="t-Triangle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-72.000000, -15.000000)" fill="#FFFFFF">\
                        <g id="t-Triangle-Group-2" transform="translate(29.000000, 0.000000)">\
                            <path d="M56.2719481,15.2473593 C57.2263246,14.695639 57.9999997,15.1409225 57.9999997,16.2463373 L58,30.7555624 C58,31.859003 57.2280325,32.3072478 56.2719485,31.7545403 L43.7227789,24.4999276 C42.7684024,23.9482072 42.7666949,23.0546789 43.7227789,22.5019715 L56.2719481,15.2473593 Z" id="t-Triangle-back"></path>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="t-Bg" class="pie percentage label singleline firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-Bg_0">VRF</span></div></div></div></div>\
        <div id="t-more-vertical" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="36"   alt="image" systemName="./images/9fe8df66-3ac1-4b07-a01d-a848692a9985.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
        </div>\
        <div id="t-menu" class="pie image firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="13" dataY="36"   alt="image" systemName="./images/066895b4-233e-4792-b154-5550b406ec47.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
        </div>\
        <div id="t-Status-bar" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="20px" dataX="0" dataY="0" >\
          <div id="t-Bg_status" class="pie percentage rectangle firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="20px" dataX="0" dataY="0" >\
           <div class="backgroundLayer"></div>\
           <div class="paddingLayer">\
             <div class="clipping">\
               <div class="content">\
                 <div class="valign">\
                   <span id="rtr-t-Bg_status_0"><br /></span>\
                 </div>\
               </div>\
             </div>\
           </div>\
          </div>\
          <div id="t-hour" class="pie label singleline firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="46px" datasizeheight="20px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-hour_0">15:45</span></div></div></div></div>\
\
          <div id="t-signals" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="61px" datasizeheight="20px" dataX="8" dataY="0"   alt="image">\
              <img src="./images/4ddcfd62-95e9-425c-88ad-7243a8588cc0.png" />\
          </div>\
        </div>\
      </div>\
      <div id="t-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="20px" dataX="55" dataY="157" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-Text_1_0"></span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-281ada69-a12b-4cc5-b5aa-3b4f53d15220" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Quick Acess" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/281ada69-a12b-4cc5-b5aa-3b4f53d15220-1586835786953.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/281ada69-a12b-4cc5-b5aa-3b4f53d15220-1586835786953-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/281ada69-a12b-4cc5-b5aa-3b4f53d15220-1586835786953-ie8.css" /><![endif]-->\
      <div id="s-Empty_screen_color_top" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="640px" dataX="0" dataY="0" >\
        <div id="s-Screen-bg" class="pie percentage richtext firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="100%" dataX="0" dataY="0" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Screen-bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Softkeys-bg" class="pie percentage rectangle firer commentable pin vpin-end hpin-center non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="48px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Softkeys-bg_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Square" class="pie image lockV firer ie-background commentable pin vpin-end hpin-end non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="74" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/737f2e61-6a0d-4c0b-9e29-a910b89e583b.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>recent</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="s-Square-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-273.000000, -16.000000)" fill="#FFFFFF">\
                        <g id="s-Square-Group-3" transform="translate(231.000000, 0.000000)">\
                            <rect id="s-Square-recent" x="42" y="16" width="16" height="16" rx="1"></rect>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Circle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-center non-processed-pin non-processed"   datasizewidth="18px" datasizeheight="18px" dataX="0" dataY="15" aspectRatio="1.0"   alt="image" systemName="./images/025304dc-7632-4290-965a-2ccfd1a09e68.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>home</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="s-Circle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-170.000000, -14.000000)">\
                        <g id="s-Circle-Group-4" transform="translate(130.000000, 0.000000)">\
                            <g id="s-Circle-home" transform="translate(40.000000, 14.000000)">\
                                <circle fill="#FFFFFF" fill-rule="evenodd" cx="10" cy="10" r="6"></circle>\
                                <circle stroke="#FFFFFF" stroke-width="2" cx="10" cy="10" r="9"></circle>\
                            </g>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Triangle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="76" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/958c6a48-d7fb-48cf-87ea-71cf9d4e5ead.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="15px" height="17px" viewBox="0 0 15 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>back</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="s-Triangle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-72.000000, -15.000000)" fill="#FFFFFF">\
                        <g id="s-Triangle-Group-2" transform="translate(29.000000, 0.000000)">\
                            <path d="M56.2719481,15.2473593 C57.2263246,14.695639 57.9999997,15.1409225 57.9999997,16.2463373 L58,30.7555624 C58,31.859003 57.2280325,32.3072478 56.2719485,31.7545403 L43.7227789,24.4999276 C42.7684024,23.9482072 42.7666949,23.0546789 43.7227789,22.5019715 L56.2719481,15.2473593 Z" id="s-Triangle-back"></path>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Bg" class="pie percentage label singleline firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Bg_0">VRF</span></div></div></div></div>\
        <div id="s-more-vertical" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="36"   alt="image" systemName="./images/9fe8df66-3ac1-4b07-a01d-a848692a9985.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
        </div>\
        <div id="s-menu" class="pie image firer click ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="13" dataY="36"   alt="image" systemName="./images/066895b4-233e-4792-b154-5550b406ec47.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
        </div>\
        <div id="s-Status-bar" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="20px" dataX="0" dataY="0" >\
          <div id="s-Bg_status" class="pie percentage rectangle firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="20px" dataX="0" dataY="0" >\
           <div class="backgroundLayer"></div>\
           <div class="paddingLayer">\
             <div class="clipping">\
               <div class="content">\
                 <div class="valign">\
                   <span id="rtr-s-Bg_status_0"><br /></span>\
                 </div>\
               </div>\
             </div>\
           </div>\
          </div>\
          <div id="s-hour" class="pie label singleline firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="46px" datasizeheight="20px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-hour_0">15:45</span></div></div></div></div>\
\
          <div id="s-signals" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="61px" datasizeheight="20px" dataX="8" dataY="0"   alt="image">\
              <img src="./images/4ddcfd62-95e9-425c-88ad-7243a8588cc0.png" />\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="20px" dataX="55" dataY="157" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0"></span></div></div></div></div>\
      <div id="s-raised_Button" class="pie button singleline firer click commentable non-processed"   datasizewidth="107px" datasizeheight="36px" dataX="31" dataY="188" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-raised_Button_0">B U T T O N</span></div></div></div></div>\
      <div id="s-raised_Button_1" class="pie button singleline firer click commentable non-processed"   datasizewidth="107px" datasizeheight="36px" dataX="190" dataY="188" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-raised_Button_1_0">B U T T O N</span></div></div></div></div>\
      <div id="s-raised_Button_2" class="pie button singleline firer click commentable non-processed"   datasizewidth="107px" datasizeheight="36px" dataX="31" dataY="252" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-raised_Button_2_0">B U T T O N</span></div></div></div></div>\
      <div id="s-raised_Button_3" class="pie button singleline firer click commentable non-processed"   datasizewidth="107px" datasizeheight="36px" dataX="190" dataY="252" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-raised_Button_3_0">B U T T O N</span></div></div></div></div>\
      <div id="s-raised_Button_4" class="pie button singleline firer click commentable non-processed"   datasizewidth="107px" datasizeheight="36px" dataX="31" dataY="314" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-raised_Button_4_0">B U T T O N</span></div></div></div></div>\
      <div id="s-raised_Button_5" class="pie button singleline firer click commentable non-processed"   datasizewidth="107px" datasizeheight="36px" dataX="190" dataY="314" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-raised_Button_5_0">B U T T O N</span></div></div></div></div>\
      <div id="s-raised_Button_6" class="pie button singleline firer click commentable non-processed"   datasizewidth="107px" datasizeheight="36px" dataX="31" dataY="382" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-raised_Button_6_0">B U T T O N</span></div></div></div></div>\
      <div id="s-raised_Button_7" class="pie button singleline firer click commentable non-processed"   datasizewidth="107px" datasizeheight="36px" dataX="190" dataY="382" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-raised_Button_7_0">B U T T O N</span></div></div></div></div>\
      <div id="s-raised_Button_9" class="pie button singleline firer click commentable non-processed"   datasizewidth="107px" datasizeheight="36px" dataX="190" dataY="437" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-raised_Button_9_0">B U T T O N</span></div></div></div></div>\
      <div id="s-raised_Button_8" class="pie button singleline firer click commentable non-processed"   datasizewidth="107px" datasizeheight="36px" dataX="31" dataY="437" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-raised_Button_8_0">B U T T O N</span></div></div></div></div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="168px" datasizeheight="28px" dataX="75" dataY="108" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">PRESET OPTIONS</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;