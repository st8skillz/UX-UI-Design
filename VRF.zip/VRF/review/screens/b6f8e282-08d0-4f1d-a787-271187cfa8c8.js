var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1586835786953.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1586835786953-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1586835786953-ie8.css" /><![endif]-->\
      <div id="t-Empty_screen_color_top" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="640px" dataX="0" dataY="0" >\
        <div id="t-Screen-bg" class="pie percentage richtext firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="100%" dataX="0" dataY="0" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-t-Screen-bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="t-Softkeys-bg" class="pie percentage rectangle firer commentable pin vpin-end hpin-center non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="48px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-t-Softkeys-bg_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="t-Square" class="pie image lockV firer ie-background commentable pin vpin-end hpin-end non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="74" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/737f2e61-6a0d-4c0b-9e29-a910b89e583b.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>recent</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="t-Square-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-273.000000, -16.000000)" fill="#FFFFFF">\
                        <g id="t-Square-Group-3" transform="translate(231.000000, 0.000000)">\
                            <rect id="t-Square-recent" x="42" y="16" width="16" height="16" rx="1"></rect>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="t-Circle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-center non-processed-pin non-processed"   datasizewidth="18px" datasizeheight="18px" dataX="0" dataY="15" aspectRatio="1.0"   alt="image" systemName="./images/025304dc-7632-4290-965a-2ccfd1a09e68.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>home</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="t-Circle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-170.000000, -14.000000)">\
                        <g id="t-Circle-Group-4" transform="translate(130.000000, 0.000000)">\
                            <g id="t-Circle-home" transform="translate(40.000000, 14.000000)">\
                                <circle fill="#FFFFFF" fill-rule="evenodd" cx="10" cy="10" r="6"></circle>\
                                <circle stroke="#FFFFFF" stroke-width="2" cx="10" cy="10" r="9"></circle>\
                            </g>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="t-Triangle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="76" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/958c6a48-d7fb-48cf-87ea-71cf9d4e5ead.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="15px" height="17px" viewBox="0 0 15 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>back</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="t-Triangle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-72.000000, -15.000000)" fill="#FFFFFF">\
                        <g id="t-Triangle-Group-2" transform="translate(29.000000, 0.000000)">\
                            <path d="M56.2719481,15.2473593 C57.2263246,14.695639 57.9999997,15.1409225 57.9999997,16.2463373 L58,30.7555624 C58,31.859003 57.2280325,32.3072478 56.2719485,31.7545403 L43.7227789,24.4999276 C42.7684024,23.9482072 42.7666949,23.0546789 43.7227789,22.5019715 L56.2719481,15.2473593 Z" id="t-Triangle-back"></path>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="t-Bg" class="pie percentage label singleline firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-Bg_0">VRF</span></div></div></div></div>\
        <div id="t-more-vertical" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="36"   alt="image" systemName="./images/9fe8df66-3ac1-4b07-a01d-a848692a9985.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
        </div>\
        <div id="t-menu" class="pie image firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="13" dataY="36"   alt="image" systemName="./images/066895b4-233e-4792-b154-5550b406ec47.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
        </div>\
        <div id="t-Status-bar" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="20px" dataX="0" dataY="0" >\
          <div id="t-Bg_status" class="pie percentage rectangle firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="20px" dataX="0" dataY="0" >\
           <div class="backgroundLayer"></div>\
           <div class="paddingLayer">\
             <div class="clipping">\
               <div class="content">\
                 <div class="valign">\
                   <span id="rtr-t-Bg_status_0"><br /></span>\
                 </div>\
               </div>\
             </div>\
           </div>\
          </div>\
          <div id="t-hour" class="pie label singleline firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="46px" datasizeheight="20px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-hour_0">15:45</span></div></div></div></div>\
\
          <div id="t-signals" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="61px" datasizeheight="20px" dataX="8" dataY="0"   alt="image">\
              <img src="./images/4ddcfd62-95e9-425c-88ad-7243a8588cc0.png" />\
          </div>\
        </div>\
      </div>\
      <div id="t-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="20px" dataX="55" dataY="157" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-Text_1_0"></span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-b6f8e282-08d0-4f1d-a787-271187cfa8c8" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Face ID ALT" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/b6f8e282-08d0-4f1d-a787-271187cfa8c8-1586835786953.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/b6f8e282-08d0-4f1d-a787-271187cfa8c8-1586835786953-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/b6f8e282-08d0-4f1d-a787-271187cfa8c8-1586835786953-ie8.css" /><![endif]-->\
      <div id="s-pad" class="group firer ie-background commentable non-processed" datasizewidth="315px" datasizeheight="490px" dataX="22" dataY="86" >\
        <div id="s-Back" class="pie image firer click ie-background commentable non-processed"   datasizewidth="20px" datasizeheight="23px" dataX="41" dataY="467"   alt="image" systemName="./images/743e1695-4be4-48bb-8ad9-e63c0f00c59d.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="34px" height="37px" viewBox="0 0 34 37" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.1 (51147) - http://www.bohemiancoding.com/sketch -->\
                <title>ic_Triangle</title>\
                <desc>Created with Sketch.</desc>\
                <defs>\
                    <path d="M170.030377,1248.74857 C163.282389,1244.83724 151.993352,1238.71549 147.957151,1236.03671 C145.159949,1234.17906 146.202002,1232.51661 147.957151,1231.52913 C153.674403,1228.05977 169.087899,1219.34126 170.645228,1218.36746 C172.543469,1217.18048 175.030086,1217.80471 175.13649,1219.90786 C175.220516,1221.56867 175.13649,1242.37259 175.13649,1246.13998 C175.13649,1249.90738 171.038536,1249.33293 170.030377,1248.74857 Z M149.627366,1233.71736 L172.469867,1246.71302 L172.469867,1220.7217 L149.627366,1233.71736 Z" id="s-Back-path-1"></path>\
                    <filter x="-12.1%" y="-8.0%" width="124.2%" height="122.3%" filterUnits="objectBoundingBox" id="s-Back-filter-2">\
                        <feMorphology radius="0.75" operator="dilate" in="SourceAlpha" result="shadowSpreadOuter1"></feMorphology>\
                        <feOffset dx="0" dy="1" in="shadowSpreadOuter1" result="shadowOffsetOuter1"></feOffset>\
                        <feGaussianBlur stdDeviation="0.75" in="shadowOffsetOuter1" result="shadowBlurOuter1"></feGaussianBlur>\
                        <feComposite in="shadowBlurOuter1" in2="SourceAlpha" operator="out" result="shadowBlurOuter1"></feComposite>\
                        <feColorMatrix values="0 0 0 0 0   0 0 0 0 0   0 0 0 0 0  0 0 0 0.225685009 0" type="matrix" in="shadowBlurOuter1"></feColorMatrix>\
                    </filter>\
                </defs>\
                <g id="s-Back-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="s-Back-Lock-Screen-Passcode" transform="translate(-144.000000, -1216.000000)">\
                        <g id="s-Back-ic_Triangle">\
                            <use fill="black" fill-opacity="1" filter="url(#s-Back-filter-2)" xlink:href="#s-Back-path-1"></use>\
                            <use stroke="#FFFFFF" stroke-width="1.5" fill="#FFFFFF" fill-rule="evenodd" xlink:href="#s-Back-path-1"></use>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Paragraph_1" class="pie richtext autofit firer click ie-background commentable non-processed"   datasizewidth="13px" datasizeheight="62px" dataX="43" dataY="75" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">1</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_10" class="pie richtext autofit firer click ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="62px" dataX="147" dataY="321" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_10_0">0</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="pie richtext autofit firer click ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="62px" dataX="147" dataY="75" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">2</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="27px" datasizeheight="21px" dataX="145" dataY="115" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">ABC</span></div></div></div></div>\
        <div id="s-Paragraph_3" class="pie richtext autofit firer click ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="62px" dataX="250" dataY="75" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">3</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_7" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="25px" datasizeheight="21px" dataX="247" dataY="115" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">DEF</span></div></div></div></div>\
        <div id="s-Paragraph_5" class="pie richtext autofit firer click ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="62px" dataX="147" dataY="155" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_5_0">5</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_8" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="22px" datasizeheight="21px" dataX="145" dataY="195" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_8_0">JKL</span></div></div></div></div>\
        <div id="s-Paragraph_6" class="pie richtext autofit firer click ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="62px" dataX="250" dataY="155" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_6_0">6</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_9" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="33px" datasizeheight="21px" dataX="247" dataY="195" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_9_0">MNO</span></div></div></div></div>\
        <div id="s-Paragraph_4" class="pie richtext autofit firer click ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="62px" dataX="43" dataY="155" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_4_0">4</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_10" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="21px" dataX="42" dataY="195" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_10_0">GHI</span></div></div></div></div>\
        <div id="s-Paragraph_8" class="pie richtext autofit firer click ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="62px" dataX="147" dataY="235" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_8_0">8</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_11" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="26px" datasizeheight="21px" dataX="145" dataY="275" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_11_0">TUV</span></div></div></div></div>\
        <div id="s-Paragraph_9" class="pie richtext autofit firer click ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="62px" dataX="250" dataY="235" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_9_0">9</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_12" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="39px" datasizeheight="21px" dataX="240" dataY="275" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_12_0">WXYZ</span></div></div></div></div>\
        <div id="s-Paragraph_7" class="pie richtext autofit firer click ie-background commentable non-processed"   datasizewidth="21px" datasizeheight="62px" dataX="43" dataY="235" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_7_0">7</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_13" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="37px" datasizeheight="21px" dataX="36" dataY="275" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_13_0">PQRS</span></div></div></div></div>\
        <div id="s-Text_14" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="21px" dataX="154" dataY="361" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_14_0">+</span></div></div></div></div>\
        <div id="s-Ok" class="pie image lockV firer click ie-background commentable non-processed"   datasizewidth="33px" datasizeheight="33px" dataX="243" dataY="329" aspectRatio="1.0"   alt="image" systemName="./images/a673093f-9c58-4cc2-add7-0679ad61c9c7.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/></svg>\
        </div>\
        <div id="s-Input_1" class="pie text firer ie-background commentable non-processed"  datasizewidth="315px" datasizeheight="44px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div>\
        <div id="s-delete" class="pie image firer click ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="291" dataY="14"   alt="image" systemName="./images/54e55d78-aaee-4ff1-a7b7-ba86a841adb2.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M22 3H7c-.69 0-1.23.35-1.59.88L0 12l5.41 8.11c.36.53.9.89 1.59.89h15c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-3 12.59L17.59 17 14 13.41 10.41 17 9 15.59 12.59 12 9 8.41 10.41 7 14 10.59 17.59 7 19 8.41 15.41 12 19 15.59z"/></svg>\
        </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;