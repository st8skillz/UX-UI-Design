var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1586835786953.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1586835786953-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1586835786953-ie8.css" /><![endif]-->\
      <div id="t-Empty_screen_color_top" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="640px" dataX="0" dataY="0" >\
        <div id="t-Screen-bg" class="pie percentage richtext firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="100%" dataX="0" dataY="0" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-t-Screen-bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="t-Softkeys-bg" class="pie percentage rectangle firer commentable pin vpin-end hpin-center non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="48px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-t-Softkeys-bg_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="t-Square" class="pie image lockV firer ie-background commentable pin vpin-end hpin-end non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="74" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/737f2e61-6a0d-4c0b-9e29-a910b89e583b.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>recent</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="t-Square-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-273.000000, -16.000000)" fill="#FFFFFF">\
                        <g id="t-Square-Group-3" transform="translate(231.000000, 0.000000)">\
                            <rect id="t-Square-recent" x="42" y="16" width="16" height="16" rx="1"></rect>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="t-Circle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-center non-processed-pin non-processed"   datasizewidth="18px" datasizeheight="18px" dataX="0" dataY="15" aspectRatio="1.0"   alt="image" systemName="./images/025304dc-7632-4290-965a-2ccfd1a09e68.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>home</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="t-Circle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-170.000000, -14.000000)">\
                        <g id="t-Circle-Group-4" transform="translate(130.000000, 0.000000)">\
                            <g id="t-Circle-home" transform="translate(40.000000, 14.000000)">\
                                <circle fill="#FFFFFF" fill-rule="evenodd" cx="10" cy="10" r="6"></circle>\
                                <circle stroke="#FFFFFF" stroke-width="2" cx="10" cy="10" r="9"></circle>\
                            </g>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="t-Triangle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="76" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/958c6a48-d7fb-48cf-87ea-71cf9d4e5ead.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="15px" height="17px" viewBox="0 0 15 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>back</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="t-Triangle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-72.000000, -15.000000)" fill="#FFFFFF">\
                        <g id="t-Triangle-Group-2" transform="translate(29.000000, 0.000000)">\
                            <path d="M56.2719481,15.2473593 C57.2263246,14.695639 57.9999997,15.1409225 57.9999997,16.2463373 L58,30.7555624 C58,31.859003 57.2280325,32.3072478 56.2719485,31.7545403 L43.7227789,24.4999276 C42.7684024,23.9482072 42.7666949,23.0546789 43.7227789,22.5019715 L56.2719481,15.2473593 Z" id="t-Triangle-back"></path>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="t-Bg" class="pie percentage label singleline firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-Bg_0">VRF</span></div></div></div></div>\
        <div id="t-more-vertical" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="36"   alt="image" systemName="./images/9fe8df66-3ac1-4b07-a01d-a848692a9985.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
        </div>\
        <div id="t-menu" class="pie image firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="13" dataY="36"   alt="image" systemName="./images/066895b4-233e-4792-b154-5550b406ec47.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
        </div>\
        <div id="t-Status-bar" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="20px" dataX="0" dataY="0" >\
          <div id="t-Bg_status" class="pie percentage rectangle firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="20px" dataX="0" dataY="0" >\
           <div class="backgroundLayer"></div>\
           <div class="paddingLayer">\
             <div class="clipping">\
               <div class="content">\
                 <div class="valign">\
                   <span id="rtr-t-Bg_status_0"><br /></span>\
                 </div>\
               </div>\
             </div>\
           </div>\
          </div>\
          <div id="t-hour" class="pie label singleline firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="46px" datasizeheight="20px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-hour_0">15:45</span></div></div></div></div>\
\
          <div id="t-signals" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="61px" datasizeheight="20px" dataX="8" dataY="0"   alt="image">\
              <img src="./images/4ddcfd62-95e9-425c-88ad-7243a8588cc0.png" />\
          </div>\
        </div>\
      </div>\
      <div id="t-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="20px" dataX="55" dataY="157" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-Text_1_0"></span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-93f1898c-f422-4019-9aae-c365cd960c0b" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="menu" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/93f1898c-f422-4019-9aae-c365cd960c0b-1586835786953.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/93f1898c-f422-4019-9aae-c365cd960c0b-1586835786953-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/93f1898c-f422-4019-9aae-c365cd960c0b-1586835786953-ie8.css" /><![endif]-->\
      <div id="s-Empty_screen_color_top" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="640px" dataX="0" dataY="0" >\
        <div id="s-Screen-bg" class="pie percentage richtext firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="100%" dataX="0" dataY="0" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Screen-bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Softkeys-bg" class="pie percentage rectangle firer commentable pin vpin-end hpin-center non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="48px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Softkeys-bg_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Square" class="pie image lockV firer ie-background commentable pin vpin-end hpin-end non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="74" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/737f2e61-6a0d-4c0b-9e29-a910b89e583b.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>recent</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="s-Square-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-273.000000, -16.000000)" fill="#FFFFFF">\
                        <g id="s-Square-Group-3" transform="translate(231.000000, 0.000000)">\
                            <rect id="s-Square-recent" x="42" y="16" width="16" height="16" rx="1"></rect>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Circle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-center non-processed-pin non-processed"   datasizewidth="18px" datasizeheight="18px" dataX="0" dataY="15" aspectRatio="1.0"   alt="image" systemName="./images/025304dc-7632-4290-965a-2ccfd1a09e68.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>home</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="s-Circle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-170.000000, -14.000000)">\
                        <g id="s-Circle-Group-4" transform="translate(130.000000, 0.000000)">\
                            <g id="s-Circle-home" transform="translate(40.000000, 14.000000)">\
                                <circle fill="#FFFFFF" fill-rule="evenodd" cx="10" cy="10" r="6"></circle>\
                                <circle stroke="#FFFFFF" stroke-width="2" cx="10" cy="10" r="9"></circle>\
                            </g>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Triangle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="76" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/958c6a48-d7fb-48cf-87ea-71cf9d4e5ead.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="15px" height="17px" viewBox="0 0 15 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>back</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="s-Triangle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-72.000000, -15.000000)" fill="#FFFFFF">\
                        <g id="s-Triangle-Group-2" transform="translate(29.000000, 0.000000)">\
                            <path d="M56.2719481,15.2473593 C57.2263246,14.695639 57.9999997,15.1409225 57.9999997,16.2463373 L58,30.7555624 C58,31.859003 57.2280325,32.3072478 56.2719485,31.7545403 L43.7227789,24.4999276 C42.7684024,23.9482072 42.7666949,23.0546789 43.7227789,22.5019715 L56.2719481,15.2473593 Z" id="s-Triangle-back"></path>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="s-Bg" class="pie percentage label singleline firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Bg_0">VRF</span></div></div></div></div>\
        <div id="s-more-vertical" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="36"   alt="image" systemName="./images/9fe8df66-3ac1-4b07-a01d-a848692a9985.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
        </div>\
        <div id="s-menu" class="pie image firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="13" dataY="36"   alt="image" systemName="./images/066895b4-233e-4792-b154-5550b406ec47.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
        </div>\
        <div id="s-Status-bar" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="20px" dataX="0" dataY="0" >\
          <div id="s-Bg_status" class="pie percentage rectangle firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="20px" dataX="0" dataY="0" >\
           <div class="backgroundLayer"></div>\
           <div class="paddingLayer">\
             <div class="clipping">\
               <div class="content">\
                 <div class="valign">\
                   <span id="rtr-s-Bg_status_0"><br /></span>\
                 </div>\
               </div>\
             </div>\
           </div>\
          </div>\
          <div id="s-hour" class="pie label singleline firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="46px" datasizeheight="20px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-hour_0">15:45</span></div></div></div></div>\
\
          <div id="s-signals" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="61px" datasizeheight="20px" dataX="8" dataY="0"   alt="image">\
              <img src="./images/4ddcfd62-95e9-425c-88ad-7243a8588cc0.png" />\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="20px" dataX="55" dataY="157" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0"></span></div></div></div></div>\
      <div id="s-Side-drawer" class="group firer ie-background commentable non-processed" datasizewidth="665px" datasizeheight="640px" dataX="-305" dataY="0" >\
        <div id="s-BgWhite_1" class="pie percentage richtext firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="100%" dataX="0" dataY="0" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-BgWhite_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Horizontal_softkeys_1" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="48px" dataX="305" dataY="592" >\
          <div id="s-Softkeys-bg_1" class="pie percentage rectangle firer commentable pin vpin-end hpin-center non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="48px" dataX="0" dataY="0" >\
           <div class="backgroundLayer"></div>\
           <div class="paddingLayer">\
             <div class="clipping">\
               <div class="content">\
                 <div class="valign">\
                   <span id="rtr-s-Softkeys-bg_1_0"></span>\
                 </div>\
               </div>\
             </div>\
           </div>\
          </div>\
          <div id="s-Square_1" class="pie image lockV firer ie-background commentable pin vpin-end hpin-end non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="74" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/b935bfbb-377e-4a42-86fa-b6c3857887f4.svg" overlay="#FFFFFF">\
              <?xml version="1.0" encoding="UTF-8"?>\
              <svg preserveAspectRatio=\'none\' width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                  <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                  <title>recent</title>\
                  <desc>Created with Sketch.</desc>\
                  <defs></defs>\
                  <g id="s-Square_1-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                      <g id="Bars/Navbar-360dp-black" transform="translate(-273.000000, -16.000000)" fill="#FFFFFF">\
                          <g id="s-Square_1-Group-3" transform="translate(231.000000, 0.000000)">\
                              <rect id="s-Square_1-recent" x="42" y="16" width="16" height="16" rx="1"></rect>\
                          </g>\
                      </g>\
                  </g>\
              </svg>\
          </div>\
          <div id="s-Circle_1" class="pie image lockV firer ie-background commentable pin vpin-end hpin-center non-processed-pin non-processed"   datasizewidth="18px" datasizeheight="18px" dataX="0" dataY="15" aspectRatio="1.0"   alt="image" systemName="./images/1daae11e-0a5d-4148-925d-27a83e33c38d.svg" overlay="#FFFFFF">\
              <?xml version="1.0" encoding="UTF-8"?>\
              <svg preserveAspectRatio=\'none\' width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                  <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                  <title>home</title>\
                  <desc>Created with Sketch.</desc>\
                  <defs></defs>\
                  <g id="s-Circle_1-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                      <g id="Bars/Navbar-360dp-black" transform="translate(-170.000000, -14.000000)">\
                          <g id="s-Circle_1-Group-4" transform="translate(130.000000, 0.000000)">\
                              <g id="s-Circle_1-home" transform="translate(40.000000, 14.000000)">\
                                  <circle fill="#FFFFFF" fill-rule="evenodd" cx="10" cy="10" r="6"></circle>\
                                  <circle stroke="#FFFFFF" stroke-width="2" cx="10" cy="10" r="9"></circle>\
                              </g>\
                          </g>\
                      </g>\
                  </g>\
              </svg>\
          </div>\
          <div id="s-Triangle_1" class="pie image lockV firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="76" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/02525187-87a9-4791-b36f-42e5045e5a41.svg" overlay="#FFFFFF">\
              <?xml version="1.0" encoding="UTF-8"?>\
              <svg preserveAspectRatio=\'none\' width="15px" height="17px" viewBox="0 0 15 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                  <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                  <title>back</title>\
                  <desc>Created with Sketch.</desc>\
                  <defs></defs>\
                  <g id="s-Triangle_1-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                      <g id="Bars/Navbar-360dp-black" transform="translate(-72.000000, -15.000000)" fill="#FFFFFF">\
                          <g id="s-Triangle_1-Group-2" transform="translate(29.000000, 0.000000)">\
                              <path d="M56.2719481,15.2473593 C57.2263246,14.695639 57.9999997,15.1409225 57.9999997,16.2463373 L58,30.7555624 C58,31.859003 57.2280325,32.3072478 56.2719485,31.7545403 L43.7227789,24.4999276 C42.7684024,23.9482072 42.7666949,23.0546789 43.7227789,22.5019715 L56.2719481,15.2473593 Z" id="s-Triangle_1-back"></path>\
                          </g>\
                      </g>\
                  </g>\
              </svg>\
          </div>\
        </div>\
        <div id="s-Black-cover_1" class="pie percentage richtext firer click commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin hidden non-processed"   datasizewidth="100%" datasizeheight="100%" dataX="0" dataY="0" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Black-cover_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-side-drawer-dialog_1" class="pie percentage dynamicpanel firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin hidden non-processed" datasizewidth="305px" datasizeheight="100%" dataX="-305" dataY="0" >\
          <div id="s-Panel_8" class="pie percentage panel default firer commentable non-processed-percentage non-processed"  datasizewidth="305px" datasizeheight="100%" >\
            <div class="backgroundLayer"></div>\
            <div class="layoutWrapper scrollable">\
                <table class="layout" summary="">\
                  <tr>\
                    <td class="layout vertical insertionpoint verticalalign Panel_8 side-drawer-dialog_1" valign="top" align="left" hSpacing="0" vSpacing="9"><div id="s-side-drawer-header_2" class="group firer ie-background commentable non-processed" datasizewidth="306px" datasizeheight="100px" dataX="0" dataY="0" >\
                  <div id="s-Rectangle_116" class="pie rectangle firer commentable non-processed"   datasizewidth="306px" datasizeheight="90px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Rectangle_116_0"></span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="s-Label_56" class="pie label multiline firer ie-background commentable non-processed"   datasizewidth="237px" datasizeheight="33px" dataX="28" dataY="45" >\
                    <div class="backgroundLayer"></div>\
                    <div class="paddingLayer">\
                      <div class="clipping">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Label_56_0">VRF</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Bg_status_2" class="pie percentage rectangle firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="20px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Bg_status_2_0"><br /></span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="100%" datasizeheight="1px" dataX="0" dataY="99" >\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
                          <g>\
                              <g>\
                                  <path id="s-Line_1" class="pie percentage line shape non-processed-shape firer ie-background commentable non-processed-percentage non-processed" d="M 0 0 L 305 0"  >\
                                  </path>\
                              </g>\
                          </g>\
                          <defs>\
                          </defs>\
                      </svg>\
                  </div>\
                </div><div id="s-Share-palette_7" class="group firer ie-background commentable non-processed" datasizewidth="306px" datasizeheight="51px" dataX="0" dataY="109" >\
                  <div id="s-Two-line-item_25" class="pie rectangle firer ie-background commentable non-processed"   datasizewidth="306px" datasizeheight="46px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Two-line-item_25_0"><br /></span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="s-Two-line-item_26" class="pie rectangle firer click commentable non-processed"   datasizewidth="294px" datasizeheight="48px" dataX="1" dataY="3" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Two-line-item_26_0">RECORD &nbsp; &nbsp; &nbsp;</span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="s-Image_17" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="27" dataY="13"   alt="image" systemName="./images/32ac4165-bcd2-4080-b6af-b52b776aa708.svg" overlay="#6200EE">\
                      <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/></svg>\
                  </div>\
                </div><div id="s-Share-palette_21" class="group firer ie-background commentable non-processed" datasizewidth="294px" datasizeheight="48px" dataX="0" dataY="169" >\
                  <div id="s-Two-line-item_35" class="pie rectangle firer click commentable non-processed"   datasizewidth="294px" datasizeheight="48px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Two-line-item_35_0">Contacts</span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="s-Image_75" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="27" dataY="11"   alt="image" systemName="./images/45b11fc7-143f-45bc-897e-fb97d5295bbf.svg" overlay="#434343">\
                      <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>\
                  </div>\
                </div><div id="s-Share-palette_3" class="group firer ie-background commentable non-processed" datasizewidth="294px" datasizeheight="48px" dataX="0" dataY="226" >\
                  <div id="s-Two-line-item_13" class="pie rectangle firer click commentable non-processed"   datasizewidth="294px" datasizeheight="48px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Two-line-item_13_0">Staticstics &amp; Dashboard</span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="s-Image_104" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="27" dataY="11"   alt="image" systemName="./images/05c2d77c-7c02-41f9-a8fa-6034168c8f17.svg" overlay="#434343">\
                      <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>\
                  </div>\
                </div><div id="s-Share-palette_22" class="group firer ie-background commentable non-processed" datasizewidth="294px" datasizeheight="48px" dataX="0" dataY="283" >\
                  <div id="s-Two-line-item_27" class="pie rectangle firer click commentable non-processed"   datasizewidth="294px" datasizeheight="48px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Two-line-item_27_0">Favorites &amp; Quick Access</span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="s-Image_30" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="27" dataY="12"   alt="image" systemName="./images/e402520d-035d-42e2-adb3-faeba86d6b5d.svg" overlay="#434343">\
                      <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>\
                  </div>\
                </div><div id="s-Share-palette_24" class="group firer ie-background commentable non-processed" datasizewidth="294px" datasizeheight="48px" dataX="0" dataY="340" >\
                  <div id="s-Two-line-item_32" class="pie rectangle firer commentable non-processed"   datasizewidth="294px" datasizeheight="48px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Two-line-item_32_0">Save<br /></span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="s-Image_4" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="27" dataY="11"   alt="image" systemName="./images/418cdb67-f17c-4392-983a-b9452138d760.svg" overlay="#434343">\
                      <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z"/></svg>\
                  </div>\
                </div><div id="s-Share-palette_25" class="group firer ie-background commentable non-processed" datasizewidth="294px" datasizeheight="48px" dataX="0" dataY="397" >\
                  <div id="s-Two-line-item_33" class="pie rectangle firer commentable non-processed"   datasizewidth="294px" datasizeheight="48px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Two-line-item_33_0">CLOUD DRIVE</span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="s-Image_7" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="27" dataY="11"   alt="image" systemName="./images/2a0709b5-6b6e-4bea-9eee-d2f967aa23c5.svg" overlay="#434343">\
                      <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM14 13v4h-4v-4H7l5-5 5 5h-3z"/></svg>\
                  </div>\
                </div><div id="s-Share-palette_26" class="group firer ie-background commentable non-processed" datasizewidth="294px" datasizeheight="48px" dataX="0" dataY="454" >\
                  <div id="s-Two-line-item_45" class="pie rectangle firer commentable non-processed"   datasizewidth="294px" datasizeheight="48px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Two-line-item_45_0">Trash</span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="s-Image_19" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="27" dataY="11"   alt="image" systemName="./images/a32e8743-d491-4dd2-b5eb-15cb6c7ba031.svg" overlay="#434343">\
                      <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>\
                  </div>\
                </div><div id="s-Two-line-item_42" class="pie rectangle firer commentable non-processed"   datasizewidth="306px" datasizeheight="20px" dataX="0" dataY="511" >\
                 <div class="backgroundLayer"></div>\
                 <div class="paddingLayer">\
                   <div class="clipping">\
                     <div class="content">\
                       <div class="valign">\
                         <span id="rtr-s-Two-line-item_42_0"></span>\
                       </div>\
                     </div>\
                   </div>\
                 </div>\
                </div><div id="s-Share-palette_27" class="group firer ie-background commentable non-processed" datasizewidth="294px" datasizeheight="48px" dataX="0" dataY="540" >\
                  <div id="s-Two-line-item_46" class="pie rectangle firer commentable non-processed"   datasizewidth="294px" datasizeheight="48px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Two-line-item_46_0">Settings</span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="s-Image_23" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="27" dataY="11"   alt="image" systemName="./images/f9d66c39-20f2-423b-9873-628ffb0c8a56.svg" overlay="#434343">\
                      <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/></svg>\
                  </div>\
                </div></td> \
                  </tr>\
                </table>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Bg_1" class="pie percentage label singleline firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Bg_1_0"></span></div></div></div></div>\
        <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="42px" datasizeheight="34px" dataX="68" dataY="36" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Title</span></div></div></div></div>\
        <div id="s-menu_1" class="pie image firer click ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="13" dataY="36"   alt="image" systemName="./images/e620ed7c-e1d4-4171-aa42-9e59ea6b3b4c.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
        </div>\
        <div id="s-more-vertical_1" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="36"   alt="image" systemName="./images/3291e5de-9f7c-4984-9c39-e0befd54f149.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
        </div>\
        <div id="s-Search_1" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="43" dataY="37"   alt="image" systemName="./images/858a3ad4-4ad3-4ea0-bd83-42fca6386214.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>\
        </div>\
        <div id="s-Share_1" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="85" dataY="37"   alt="image" systemName="./images/fc80b101-4d8e-4826-92b2-c7e37db29817.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z"/></svg>\
        </div>\
        <div id="s-Status-bar_1" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="20px" dataX="305" dataY="0" >\
          <div id="s-Bg_status_3" class="pie percentage rectangle firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="20px" dataX="0" dataY="0" >\
           <div class="backgroundLayer"></div>\
           <div class="paddingLayer">\
             <div class="clipping">\
               <div class="content">\
                 <div class="valign">\
                   <span id="rtr-s-Bg_status_3_0"><br /></span>\
                 </div>\
               </div>\
             </div>\
           </div>\
          </div>\
          <div id="s-hour_1" class="pie label singleline firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="46px" datasizeheight="20px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-hour_1_0">15:45</span></div></div></div></div>\
\
          <div id="s-signals_1" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="61px" datasizeheight="20px" dataX="8" dataY="0"   alt="image">\
              <img src="./images/e45a773f-d3c9-4d9e-ac05-9c77428ad24e.png" />\
          </div>\
        </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;