var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1586835786953.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1586835786953-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1586835786953-ie8.css" /><![endif]-->\
      <div id="t-Empty_screen_color_top" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="640px" dataX="0" dataY="0" >\
        <div id="t-Screen-bg" class="pie percentage richtext firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="100%" dataX="0" dataY="0" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-t-Screen-bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="t-Softkeys-bg" class="pie percentage rectangle firer commentable pin vpin-end hpin-center non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="48px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-t-Softkeys-bg_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="t-Square" class="pie image lockV firer ie-background commentable pin vpin-end hpin-end non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="74" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/737f2e61-6a0d-4c0b-9e29-a910b89e583b.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>recent</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="t-Square-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-273.000000, -16.000000)" fill="#FFFFFF">\
                        <g id="t-Square-Group-3" transform="translate(231.000000, 0.000000)">\
                            <rect id="t-Square-recent" x="42" y="16" width="16" height="16" rx="1"></rect>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="t-Circle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-center non-processed-pin non-processed"   datasizewidth="18px" datasizeheight="18px" dataX="0" dataY="15" aspectRatio="1.0"   alt="image" systemName="./images/025304dc-7632-4290-965a-2ccfd1a09e68.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>home</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="t-Circle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-170.000000, -14.000000)">\
                        <g id="t-Circle-Group-4" transform="translate(130.000000, 0.000000)">\
                            <g id="t-Circle-home" transform="translate(40.000000, 14.000000)">\
                                <circle fill="#FFFFFF" fill-rule="evenodd" cx="10" cy="10" r="6"></circle>\
                                <circle stroke="#FFFFFF" stroke-width="2" cx="10" cy="10" r="9"></circle>\
                            </g>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="t-Triangle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="76" dataY="17" aspectRatio="1.0"   alt="image" systemName="./images/958c6a48-d7fb-48cf-87ea-71cf9d4e5ead.svg" overlay="#FFFFFF">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="15px" height="17px" viewBox="0 0 15 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                <title>back</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="t-Triangle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="Bars/Navbar-360dp-black" transform="translate(-72.000000, -15.000000)" fill="#FFFFFF">\
                        <g id="t-Triangle-Group-2" transform="translate(29.000000, 0.000000)">\
                            <path d="M56.2719481,15.2473593 C57.2263246,14.695639 57.9999997,15.1409225 57.9999997,16.2463373 L58,30.7555624 C58,31.859003 57.2280325,32.3072478 56.2719485,31.7545403 L43.7227789,24.4999276 C42.7684024,23.9482072 42.7666949,23.0546789 43.7227789,22.5019715 L56.2719481,15.2473593 Z" id="t-Triangle-back"></path>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
        <div id="t-Bg" class="pie percentage label singleline firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="76px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-Bg_0">VRF</span></div></div></div></div>\
        <div id="t-more-vertical" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="8" dataY="36"   alt="image" systemName="./images/9fe8df66-3ac1-4b07-a01d-a848692a9985.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
        </div>\
        <div id="t-menu" class="pie image firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="13" dataY="36"   alt="image" systemName="./images/066895b4-233e-4792-b154-5550b406ec47.svg" overlay="#FFFFFF">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
        </div>\
        <div id="t-Status-bar" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="20px" dataX="0" dataY="0" >\
          <div id="t-Bg_status" class="pie percentage rectangle firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="20px" dataX="0" dataY="0" >\
           <div class="backgroundLayer"></div>\
           <div class="paddingLayer">\
             <div class="clipping">\
               <div class="content">\
                 <div class="valign">\
                   <span id="rtr-t-Bg_status_0"><br /></span>\
                 </div>\
               </div>\
             </div>\
           </div>\
          </div>\
          <div id="t-hour" class="pie label singleline firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="46px" datasizeheight="20px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-hour_0">15:45</span></div></div></div></div>\
\
          <div id="t-signals" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="61px" datasizeheight="20px" dataX="8" dataY="0"   alt="image">\
              <img src="./images/4ddcfd62-95e9-425c-88ad-7243a8588cc0.png" />\
          </div>\
        </div>\
      </div>\
      <div id="t-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="20px" dataX="55" dataY="157" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-Text_1_0"></span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-4208328e-8115-4e27-b2c5-8e1e46a57826" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Contacts" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/4208328e-8115-4e27-b2c5-8e1e46a57826-1586835786953.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/4208328e-8115-4e27-b2c5-8e1e46a57826-1586835786953-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/4208328e-8115-4e27-b2c5-8e1e46a57826-1586835786953-ie8.css" /><![endif]-->\
      <div id="s-ContactsScreen" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="640px" dataX="0" dataY="0" >\
        <div id="s-inbox-dinamicpanel" class="pie percentage dynamicpanel firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed" datasizewidth="100%" datasizeheight="85%" dataX="0" dataY="90" >\
          <div id="s-All" class="pie percentage panel default firer commentable non-processed-percentage non-processed"  datasizewidth="100%" datasizeheight="85%" >\
            <div class="backgroundLayer"></div>\
            <div class="layoutWrapper scrollable">\
                <table class="layout" summary="">\
                  <tr>\
                    <td class="layout vertical insertionpoint verticalalign All inbox-dinamicpanel" valign="top" align="center" hSpacing="0" vSpacing="0"><div id="s-Group_4" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="0" >\
                  <div id="s-Rectangle_12" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Rectangle_12_0">Sandra Adams</span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="s-Image_110" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="15" dataY="18"   alt="image" systemName="./images/100f2574-8838-4025-9e68-46599957f8a0.svg" overlay="#007AFF">\
                      <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>\
                  </div>\
                  <div id="shapewrapper-s-Ellipse_9" class="shapewrapper shapewrapper-s-Ellipse_9 non-processed"   datasizewidth="42px" datasizeheight="42px" dataX="81" dataY="11" >\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_9" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_9)">\
                                      <ellipse id="s-Ellipse_9" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_9" class="clipPath">\
                                      <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="shapert-clipping">\
                          <div id="shapert-s-Ellipse_9" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_9_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div><div id="s-Group_7" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="61" >\
                  <div id="s-Rectangle_15" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Rectangle_15_0">Imma Jones<br /></span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="shapewrapper-s-Ellipse_8" class="shapewrapper shapewrapper-s-Ellipse_8 non-processed"   datasizewidth="42px" datasizeheight="42px" dataX="81" dataY="11" >\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_8" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_8)">\
                                      <ellipse id="s-Ellipse_8" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_8" class="clipPath">\
                                      <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="shapert-clipping">\
                          <div id="shapert-s-Ellipse_8" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_8_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div><div id="s-Group_2" class="group firer ie-background commentable non-processed" datasizewidth="359px" datasizeheight="61px" dataX="0" dataY="122" >\
                  <div id="s-Rectangle_3" class="pie rectangle firer commentable non-processed"   datasizewidth="359px" datasizeheight="61px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Rectangle_3_0">Mark Smith</span><span id="rtr-s-Rectangle_3_1"><br /></span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="shapewrapper-s-Ellipse_7" class="shapewrapper shapewrapper-s-Ellipse_7 non-processed"   datasizewidth="42px" datasizeheight="42px" dataX="81" dataY="11" >\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_7" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_7)">\
                                      <ellipse id="s-Ellipse_7" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_7" class="clipPath">\
                                      <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="shapert-clipping">\
                          <div id="shapert-s-Ellipse_7" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_7_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div><div id="s-Group_6" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="183" >\
                  <div id="s-Rectangle_14" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Rectangle_14_0">Anna Hunt</span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="shapewrapper-s-Ellipse_6" class="shapewrapper shapewrapper-s-Ellipse_6 non-processed"   datasizewidth="42px" datasizeheight="42px" dataX="81" dataY="11" >\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_6" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_6)">\
                                      <ellipse id="s-Ellipse_6" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_6" class="clipPath">\
                                      <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="shapert-clipping">\
                          <div id="shapert-s-Ellipse_6" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_6_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div><div id="s-Group_3" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="244" >\
                  <div id="s-Rectangle_11" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Rectangle_11_0">Hazel Hatchett</span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="13px" datasizeheight="31px" dataX="20" dataY="17" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">K</span></div></div></div></div>\
                  <div id="shapewrapper-s-Ellipse_5" class="shapewrapper shapewrapper-s-Ellipse_5 non-processed"   datasizewidth="42px" datasizeheight="42px" dataX="81" dataY="11" >\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_5" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_5)">\
                                      <ellipse id="s-Ellipse_5" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_5" class="clipPath">\
                                      <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="shapert-clipping">\
                          <div id="shapert-s-Ellipse_5" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_5_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div><div id="s-Group_9" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="305" >\
                  <div id="s-Rectangle_17" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Rectangle_17_0">Frederick Pryce</span><span id="rtr-s-Rectangle_17_1"><br /></span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="shapewrapper-s-Ellipse_4" class="shapewrapper shapewrapper-s-Ellipse_4 non-processed"   datasizewidth="42px" datasizeheight="42px" dataX="81" dataY="12" >\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_4" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_4)">\
                                      <ellipse id="s-Ellipse_4" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_4" class="clipPath">\
                                      <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="shapert-clipping">\
                          <div id="shapert-s-Ellipse_4" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_4_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div><div id="s-Group_5" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="366" >\
                  <div id="s-Rectangle_10" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Rectangle_10_0">Gwyneth Lore</span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="31px" dataX="20" dataY="17" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">L</span></div></div></div></div>\
                  <div id="shapewrapper-s-Ellipse_3" class="shapewrapper shapewrapper-s-Ellipse_3 non-processed"   datasizewidth="42px" datasizeheight="42px" dataX="80" dataY="11" >\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_3" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_3)">\
                                      <ellipse id="s-Ellipse_3" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_3" class="clipPath">\
                                      <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="shapert-clipping">\
                          <div id="shapert-s-Ellipse_3" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_3_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div><div id="s-Group_8" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="427" >\
                  <div id="s-Rectangle_16" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Rectangle_16_0">Kenny Mcleod</span><span id="rtr-s-Rectangle_16_1"><br /></span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="s-Text_6" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="18px" datasizeheight="31px" dataX="16" dataY="17" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">M</span></div></div></div></div>\
                  <div id="shapewrapper-s-Ellipse_2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="42px" datasizeheight="42px" dataX="81" dataY="11" >\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_2)">\
                                      <ellipse id="s-Ellipse_2" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                                      <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="shapert-clipping">\
                          <div id="shapert-s-Ellipse_2" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_2_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div><div id="s-Group_10" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="488" >\
                  <div id="s-Rectangle_13" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="61px" dataX="0" dataY="0" >\
                   <div class="backgroundLayer"></div>\
                   <div class="paddingLayer">\
                     <div class="clipping">\
                       <div class="content">\
                         <div class="valign">\
                           <span id="rtr-s-Rectangle_13_0">Daniel</span><span id="rtr-s-Rectangle_13_1"> Vanfleet<br /></span>\
                         </div>\
                       </div>\
                     </div>\
                   </div>\
                  </div>\
                  <div id="s-Text_7" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="13px" datasizeheight="31px" dataX="17" dataY="17" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">V</span></div></div></div></div>\
                  <div id="shapewrapper-s-Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="42px" datasizeheight="42px" dataX="78" dataY="12" >\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_1)">\
                                      <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                                      <ellipse cx="21.0" cy="21.0" rx="21.0" ry="21.0">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="shapert-clipping">\
                          <div id="shapert-s-Ellipse_1" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_1_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div><div id="s-Rectangle_18" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="120px" dataX="0" dataY="549" >\
                 <div class="backgroundLayer"></div>\
                 <div class="paddingLayer">\
                   <div class="clipping">\
                     <div class="content">\
                       <div class="valign">\
                         <span id="rtr-s-Rectangle_18_0"><br /></span>\
                       </div>\
                     </div>\
                   </div>\
                 </div>\
                </div></td> \
                  </tr>\
                </table>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Horizontal_softkeys" class="group firer ie-background commentable non-processed" datasizewidth="360px" datasizeheight="48px" dataX="0" dataY="592" >\
          <div id="s-Softkeys-bg" class="pie percentage rectangle firer commentable pin vpin-end hpin-center non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="48px" dataX="0" dataY="0" >\
           <div class="backgroundLayer"></div>\
           <div class="paddingLayer">\
             <div class="clipping">\
               <div class="content">\
                 <div class="valign">\
                   <span id="rtr-s-Softkeys-bg_0"></span>\
                 </div>\
               </div>\
             </div>\
           </div>\
          </div>\
          <div id="s-Square" class="pie image lockV firer ie-background commentable pin vpin-end hpin-end non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="74" dataY="16" aspectRatio="1.0"   alt="image" systemName="./images/481a273b-2807-41bd-a55d-e07003192487.svg" overlay="#FFFFFF">\
              <?xml version="1.0" encoding="UTF-8"?>\
              <svg preserveAspectRatio=\'none\' width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                  <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                  <title>recent</title>\
                  <desc>Created with Sketch.</desc>\
                  <defs></defs>\
                  <g id="s-Square-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                      <g id="Bars/Navbar-360dp-black" transform="translate(-273.000000, -16.000000)" fill="#FFFFFF">\
                          <g id="s-Square-Group-3" transform="translate(231.000000, 0.000000)">\
                              <rect id="s-Square-recent" x="42" y="16" width="16" height="16" rx="1"></rect>\
                          </g>\
                      </g>\
                  </g>\
              </svg>\
          </div>\
          <div id="s-Circle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-center non-processed-pin non-processed"   datasizewidth="18px" datasizeheight="18px" dataX="0" dataY="14" aspectRatio="1.0"   alt="image" systemName="./images/7ba1f8a2-6421-4e52-bb56-5e448db889a4.svg" overlay="#FFFFFF">\
              <?xml version="1.0" encoding="UTF-8"?>\
              <svg preserveAspectRatio=\'none\' width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                  <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                  <title>home</title>\
                  <desc>Created with Sketch.</desc>\
                  <defs></defs>\
                  <g id="s-Circle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                      <g id="Bars/Navbar-360dp-black" transform="translate(-170.000000, -14.000000)">\
                          <g id="s-Circle-Group-4" transform="translate(130.000000, 0.000000)">\
                              <g id="s-Circle-home" transform="translate(40.000000, 14.000000)">\
                                  <circle fill="#FFFFFF" fill-rule="evenodd" cx="10" cy="10" r="6"></circle>\
                                  <circle stroke="#FFFFFF" stroke-width="2" cx="10" cy="10" r="9"></circle>\
                              </g>\
                          </g>\
                      </g>\
                  </g>\
              </svg>\
          </div>\
          <div id="s-Triangle" class="pie image lockV firer ie-background commentable pin vpin-end hpin-beginning non-processed-pin non-processed"   datasizewidth="15px" datasizeheight="15px" dataX="76" dataY="16" aspectRatio="1.0"   alt="image" systemName="./images/fccfd3af-8b71-4d18-9135-ea838a04ab6e.svg" overlay="#FFFFFF">\
              <?xml version="1.0" encoding="UTF-8"?>\
              <svg preserveAspectRatio=\'none\' width="15px" height="17px" viewBox="0 0 15 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                  <!-- Generator: Sketch 49.2 (51160) - http://www.bohemiancoding.com/sketch -->\
                  <title>back</title>\
                  <desc>Created with Sketch.</desc>\
                  <defs></defs>\
                  <g id="s-Triangle-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                      <g id="Bars/Navbar-360dp-black" transform="translate(-72.000000, -15.000000)" fill="#FFFFFF">\
                          <g id="s-Triangle-Group-2" transform="translate(29.000000, 0.000000)">\
                              <path d="M56.2719481,15.2473593 C57.2263246,14.695639 57.9999997,15.1409225 57.9999997,16.2463373 L58,30.7555624 C58,31.859003 57.2280325,32.3072478 56.2719485,31.7545403 L43.7227789,24.4999276 C42.7684024,23.9482072 42.7666949,23.0546789 43.7227789,22.5019715 L56.2719481,15.2473593 Z" id="s-Triangle-back"></path>\
                          </g>\
                      </g>\
                  </g>\
              </svg>\
          </div>\
        </div>\
        <div id="s-Float-button-plus" class="group firer ie-background commentable non-processed" datasizewidth="56px" datasizeheight="56px" dataX="288" dataY="529" >\
          <div id="shapewrapper-s-Ellipse_23" class="shapewrapper shapewrapper-s-Ellipse_23 non-processed"   datasizewidth="56px" datasizeheight="56px" dataX="16" dataY="55" >\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_23" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_23)">\
                              <ellipse id="s-Ellipse_23" class="pie ellipse shape non-processed-shape firer commentable pin vpin-end hpin-end non-processed-pin non-processed" cx="28.0" cy="28.0" rx="28.0" ry="28.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_23" class="clipPath">\
                              <ellipse cx="28.0" cy="28.0" rx="28.0" ry="28.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="shapert-clipping">\
                  <div id="shapert-s-Ellipse_23" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_23_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_24" class="shapewrapper shapewrapper-s-Ellipse_24 non-processed"   datasizewidth="56px" datasizeheight="56px" dataX="16" dataY="55" >\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_24" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_24)">\
                              <ellipse id="s-Ellipse_24" class="pie ellipse shape non-processed-shape firer commentable pin vpin-end hpin-end non-processed-pin hidden non-processed" cx="28.0" cy="28.0" rx="28.0" ry="28.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_24" class="clipPath">\
                              <ellipse cx="28.0" cy="28.0" rx="28.0" ry="28.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="shapert-clipping">\
                  <div id="shapert-s-Ellipse_24" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_24_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="s-plus_2" class="pie image firer click ie-background commentable pin vpin-end hpin-end non-processed-pin non-processed"   datasizewidth="38px" datasizeheight="36px" dataX="26" dataY="65"   alt="image" systemName="./images/c99cfa4c-8ea4-4613-8c91-cb0b5d1f1693.svg" overlay="#FFFFFF">\
              <?xml version="1.0" encoding="utf-8"?>\
              <!-- Generator: Adobe Illustrator 21.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
              <svg preserveAspectRatio=\'none\' version="1.1" id="s-plus_2-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
              	 viewBox="0 0 38.3 36.4" style="enable-background:new 0 0 38.3 36.4;" xml:space="preserve">\
              <style type="text/css">\
              	#s-plus_2 .st0{fill:#FFFFFF;fill-opacity:0.9;}\
              </style>\
              <polygon class="st0" points="20.6,16.8 20.5,8.7 17.8,8.7 17.8,16.9 9.7,16.9 9.7,19.6 17.9,19.6 17.9,27.7 20.6,27.7 20.6,19.6 \
              	28.7,19.5 28.7,16.8 "/>\
              </svg>\
\
          </div>\
        </div>\
        <div id="s-Rectangle_1" class="pie percentage rectangle firer commentable pin vpin-beginning hpin-center non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="90px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Rectangle_1_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Input_search" class="pie percentage dynamicpanel firer commentable pin vpin-beginning hpin-center non-processed-percentage non-processed-pin non-processed" datasizewidth="93%" datasizeheight="54px" dataX="0" dataY="30" >\
          <div id="s-Components_panel_1" class="pie percentage panel default firer commentable non-processed-percentage non-processed"  datasizewidth="93%" datasizeheight="54px" >\
            <div class="backgroundLayer"></div>\
            <div class="layoutWrapper scrollable">\
                <div id="s-Input_3" class="pie percentage text firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"  datasizewidth="85%" datasizeheight="44px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Search contacts"/></div></div>  </div></div>\
                <div id="s-menu_3" class="pie image firer click ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="13" dataY="9"   alt="image" systemName="./images/45f1d7a4-9939-4660-8c1a-42ef460e64a9.svg" overlay="#7D7D7D">\
                    <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
                </div>\
                <div id="shapewrapper-s-User_2" class="shapewrapper shapewrapper-s-User_2 non-processed"   datasizewidth="33px" datasizeheight="33px" dataX="13" dataY="0" >\
                    <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-User_2" class="svgContainer" style="width:100%; height:100%;">\
                        <g>\
                            <g clip-path="url(#clip-s-User_2)">\
                                    <ellipse id="s-User_2" class="pie ellipse shape non-processed-shape firer commentable pin vpin-center hpin-end non-processed-pin non-processed" cx="16.5" cy="16.5" rx="16.5" ry="16.5">\
                                    </ellipse>\
                            </g>\
                        </g>\
                        <defs>\
                            <clipPath id="clip-s-User_2" class="clipPath">\
                                    <ellipse cx="16.5" cy="16.5" rx="16.5" ry="16.5">\
                                    </ellipse>\
                            </clipPath>\
                        </defs>\
                    </svg>\
                    <div class="shapert-clipping">\
                        <div id="shapert-s-User_2" class="content firer" >\
                            <div class="valign">\
                                <span id="rtr-s-User_2_0"></span>\
                            </div>\
                        </div>\
                    </div>\
                </div>\
                <div id="s-more-vertical_1" class="pie image lockV firer ie-background commentable pin vpin-center hpin-end non-processed-pin non-processed"   datasizewidth="27px" datasizeheight="26px" dataX="54" dataY="0" aspectRatio="0.962963"   alt="image" systemName="./images/663d6b5a-7aa4-465e-a145-16f611b4b07c.svg" overlay="#5D5E61">\
                    <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>\
                </div>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Status-bar" class="group firer ie-background commentable non-processed" datasizewidth="352px" datasizeheight="20px" dataX="0" dataY="0" >\
          <div id="s-hour_1" class="pie label singleline firer ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="46px" datasizeheight="20px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-hour_1_0">15:45</span></div></div></div></div>\
\
          <div id="s-signals_1" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="61px" datasizeheight="20px" dataX="8" dataY="0"   alt="image">\
              <img src="./images/4354b6cb-7518-4f84-921e-6a91c38a0ed9.png" />\
          </div>\
        </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;